require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
        
const app = express();
const PORT = process.env.PORT || 4242;

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || '');
const twilio = require('twilio')(process.env.TWILIO_ACCOUNT_SID || '', process.env.TWILIO_AUTH_TOKEN || '');

app.use(require('cors')());
// raw body required for Stripe webhook signature verification
app.use((req, res, next) => {
  if (req.originalUrl === '/webhook') {
    bodyParser.raw({ type: 'application/json' })(req, res, next);
  } else {
    bodyParser.json()(req, res, next);
  }
});

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
const SIGNUPS_FILE = path.join(DATA_DIR, 'signups.json');
if (!fs.existsSync(SIGNUPS_FILE)) fs.writeFileSync(SIGNUPS_FILE, '[]');

// POST /api/signup
app.post('/api/signup', async (req, res) => {
  try {
    const { name, business, email, phone, plan } = req.body || {};
    if (!name || !business || !email) return res.status(400).json({ message: 'name, business and email required' });
    const signup = { id: Date.now(), name, business, email, phone, plan: plan || 'starter', created_at: new Date().toISOString() };
    const arr = JSON.parse(fs.readFileSync(SIGNUPS_FILE));
    arr.push(signup);
    fs.writeFileSync(SIGNUPS_FILE, JSON.stringify(arr, null, 2));
    return res.json({ ok: true, signup });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'server error' });
  }
});

// POST /api/create-checkout-session
app.post('/api/create-checkout-session', async (req, res) => {
  try {
    const { plan, email } = req.body;
    const priceMap = {
      starter: process.env.STRIPE_PRICE_STARTER,
      pro: process.env.STRIPE_PRICE_PRO,
      business: process.env.STRIPE_PRICE_BUSINESS,
    };
    const priceId = priceMap[plan] || process.env.STRIPE_PRICE_STARTER;
    if (!priceId) return res.status(400).json({ message: 'Price not configured' });

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      subscription_data: { metadata: { email: email || '' } },
      success_url: `${process.env.BASE_URL || 'http://localhost:4242'}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.BASE_URL || 'http://localhost:4242'}/cancel`,
    });
    res.json({ url: session.url, id: session.id });
  } catch (err) {
    console.error('checkout error', err.message);
    res.status(500).json({ message: 'checkout error' });
  }
});

// Stripe webhook
app.post('/webhook', (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed.', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  // Handle the event
  switch (event.type) {
    case 'checkout.session.completed':
      console.log('Checkout session completed', event.data.object.id);
      break;
    case 'invoice.payment_succeeded':
      console.log('Payment succeeded for', event.data.object.customer);
      break;
    default:
      console.log(`Unhandled event type ${event.type}`);
  }
  res.json({ received: true });
});

// POST /api/reminders/send - minimal Twilio stub
app.post('/api/reminders/send', async (req, res) => {
  try {
    const { to, body } = req.body;
    if (!to || !body) return res.status(400).json({ message: 'to and body required' });
    // send SMS via Twilio (live credentials required in .env)
    const from = process.env.TWILIO_FROM_NUMBER || '+15005550006';
    const message = await twilio.messages.create({ body, from, to });
    return res.json({ ok: true, sid: message.sid });
  } catch (err) {
    console.error('Twilio error', err.message);
    return res.status(500).json({ message: 'sms error' });
  }
});

app.listen(PORT, () => console.log(`NoShowShield backend running on ${PORT}`));
