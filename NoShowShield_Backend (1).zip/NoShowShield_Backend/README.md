# NoShowShield Backend (MVP)

Minimal Node.js + Express backend to accept signups and create Stripe Checkout sessions.

## Quick start

1. Copy `.env.example` to `.env` and fill your credentials.
2. `npm install`
3. `npm run dev` (requires nodemon) or `npm start`

## Endpoints

- `POST /api/signup` - store signup and return a simple confirmation.
- `POST /api/create-checkout-session` - create a Stripe Checkout Session for subscription.
- `POST /webhook` - Stripe webhook endpoint (verify signature).
- `POST /api/reminders/send` - (stub) trigger reminder send via Twilio.

This is a starter template — replace file storage with a proper DB (Postgres/Supabase) as you scale.
