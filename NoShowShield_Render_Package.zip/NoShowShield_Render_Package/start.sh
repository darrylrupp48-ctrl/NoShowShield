#!/usr/bin/env bash
set -e
if [ -d "frontend" ] && [ -f "frontend/package.json" ]; then
  echo "Building frontend..."
  cd frontend
  npm ci --silent
  npm run build --silent
  cd ..
fi
echo "Starting backend..."
uvicorn backend.main:app --host 0.0.0.0 --port ${PORT:-10000}
