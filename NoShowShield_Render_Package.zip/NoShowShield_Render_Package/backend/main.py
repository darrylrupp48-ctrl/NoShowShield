from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
from typing import List
from datetime import datetime, timedelta
import os

app = FastAPI(title="NoShowShield Fullstack")

class Appointment(BaseModel):
    id: int
    client_name: str
    time: datetime
    status: str
    value: float

now = datetime.utcnow()
APPOINTMENTS = [
    Appointment(id=1, client_name="Ava Smith", time=now + timedelta(hours=4), status="booked", value=75.0),
    Appointment(id=2, client_name="Liam Jones", time=now + timedelta(days=1), status="booked", value=60.0),
    Appointment(id=3, client_name="Olivia Brown", time=now - timedelta(days=1), status="no_show", value=80.0),
    Appointment(id=4, client_name="Noah Davis", time=now + timedelta(hours=24), status="confirmed", value=50.0),
]

@app.get('/api/metrics')
def get_metrics():
    return {
        "revenue_saved": 12430.00,
        "success_rate": 94,
        "upcoming_clients": sum(1 for a in APPOINTMENTS if a.time > now and a.status in ('booked','confirmed')),
        "missed_appointments": sum(1 for a in APPOINTMENTS if a.status == 'no_show')
    }

@app.get('/api/appointments', response_model=List[Appointment])
def list_appointments():
    return APPOINTMENTS

@app.post('/api/appointments', response_model=Appointment)
def create_appointment(appt: Appointment):
    appt.id = max(a.id for a in APPOINTMENTS) + 1 if APPOINTMENTS else 1
    APPOINTMENTS.append(appt)
    return appt

# Serve frontend if built
dist_dir = os.path.join(os.path.dirname(__file__), '..', 'frontend', 'dist')
if os.path.isdir(dist_dir):
    app.mount('/', StaticFiles(directory=dist_dir), name='frontend')
    @app.get('/{full_path:path}')
    async def spa_handler(full_path: str, request: Request):
        return FileResponse(os.path.join(dist_dir, 'index.html'))
else:
    @app.get('/')
    def root_info():
        return JSONResponse({'status':'no-frontend','message':'Frontend build not found. Build frontend before deploy.'})
