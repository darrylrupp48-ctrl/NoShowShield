import React, { useEffect, useState } from 'react'

export default function Dashboard() {
  const [metrics, setMetrics] = useState(null)

  useEffect(() => {
    fetch(`/api/metrics`)
      .then(r => r.json())
      .then(setMetrics)
      .catch(err => console.error('Fetch metrics error', err))
  }, [])

  if (!metrics) return <div className="container"><h2>Loading dashboard…</h2></div>

  return (
    <div className="container">
      <header className="header">
        <div className="logo">NoShowShield</div>
        <div className="tagline">Shield Your Time. Secure Your Growth.</div>
      </header>

      <section className="cards">
        <div className="card">
          <div className="label">Revenue Saved</div>
          <div className="value">${metrics.revenue_saved.toLocaleString()}</div>
        </div>
        <div className="card">
          <div className="label">Success Rate</div>
          <div className="value">{metrics.success_rate}%</div>
        </div>
        <div className="card">
          <div className="label">Upcoming Clients</div>
          <div className="value">{metrics.upcoming_clients}</div>
        </div>
        <div className="card">
          <div className="label">Missed Appointments</div>
          <div className="value">{metrics.missed_appointments}</div>
        </div>
      </section>
      <section className="appointments">
        <h3>Upcoming Appointments (Demo)</h3>
        <AppointmentsList />
      </section>
    </div>
  )
}

function AppointmentsList() {
  const [appts, setAppts] = useState([])
  useEffect(()=>{
    fetch(`/api/appointments`).then(r=>r.json()).then(setAppts).catch(()=>{})
  },[])
  if(!appts.length) return <div className="muted">No appointments (demo)</div>
  return (
    <table className="appt-table">
      <thead><tr><th>Client</th><th>Time (UTC)</th><th>Status</th><th>Value</th></tr></thead>
      <tbody>
        {appts.map(a=> (
          <tr key={a.id}>
            <td>{a.client_name}</td>
            <td>{new Date(a.time).toLocaleString()}</td>
            <td>{a.status}</td>
            <td>${a.value.toFixed(2)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
