NoShowShield — Full-stack Render template
Generated: 2025-10-11 20:22 UTC

How to use:
1. Create a GitHub repo called 'NoShowShield' and upload these files (or push with git).
2. On Render create a Web Service:
   - Root Directory: (leave blank)
   - Environment: Python 3
   - Build Command: bash start.sh
   - Start Command: bash start.sh
3. After deploy, your site will be at https://<your-render-name>.onrender.com

Notes:
- API endpoints under /api/*
- To test locally, run backend with uvicorn and frontend with npm run dev.
